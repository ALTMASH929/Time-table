package com.myday.app;

import android.app.*;
import android.content.*;
import android.os.*;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent){
        String title=intent.getStringExtra("title");
        String body=intent.getStringExtra("body");
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        Intent open=new Intent(context,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(context,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b;
        if(Build.VERSION.SDK_INT>=26) b=new Notification.Builder(context,"myday_reminders");
        else b=new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_popup_reminder)
         .setContentTitle(title==null?"MyDay Reminder":title)
         .setContentText(body==null?"Time for your activity":body)
         .setStyle(new Notification.BigTextStyle().bigText(body==null?"":body))
         .setContentIntent(pi).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER)
         .setPriority(Notification.PRIORITY_HIGH).setVibrate(new long[]{0,400,200,400});
        nm.notify((int)(System.currentTimeMillis()%100000),b.build());
    }
}