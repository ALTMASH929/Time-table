package com.myday.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import org.json.*;

public class MainActivity extends Activity {
    WebView web;
    static final int NOTIF_REQ=1001;
    static final String CHANNEL="myday_reminders";

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        createChannel();
        web=findViewById(R.id.webView);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AndroidMyDay");
        web.loadUrl("file:///android_asset/index.html");
    }

    void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL,"MyDay Reminders",NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("Timetable, gym and diet reminders");
            c.enableVibration(true);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    class Bridge {
        @JavascriptInterface public void requestNotificationPermission(){
            if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIF_REQ);
            else Toast.makeText(MainActivity.this,"Notifications are enabled",Toast.LENGTH_SHORT).show();
        }

        @JavascriptInterface public void scheduleTimetable(String json){
            try{
                JSONObject root=new JSONObject(json);
                JSONArray items=root.getJSONArray("items");
                AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
                for(int i=0;i<items.length();i++){
                    JSONObject x=items.getJSONObject(i);
                    String t=x.optString("time","");
                    String[] parts=t.split(":");
                    if(parts.length<2) continue;
                    int h=Integer.parseInt(parts[0]), m=Integer.parseInt(parts[1]);
                    Intent in=new Intent(MainActivity.this,ReminderReceiver.class);
                    in.putExtra("title","MyDay • "+x.optString("activity","Activity"));
                    in.putExtra("body",x.optString("displayTime",t)+" • "+x.optString("details",""));
                    in.putExtra("id",7000+i);
                    PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this,7000+i,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                    java.util.Calendar cal=java.util.Calendar.getInstance();
                    cal.set(java.util.Calendar.HOUR_OF_DAY,h); cal.set(java.util.Calendar.MINUTE,m); cal.set(java.util.Calendar.SECOND,0); cal.set(java.util.Calendar.MILLISECOND,0);
                    if(cal.getTimeInMillis()<=System.currentTimeMillis()) cal.add(java.util.Calendar.DAY_OF_YEAR,1);
                    if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
                    else am.setExact(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
                }
                runOnUiThread(()->Toast.makeText(MainActivity.this,"Native reminders scheduled ✅",Toast.LENGTH_SHORT).show());
            }catch(Exception e){ runOnUiThread(()->Toast.makeText(MainActivity.this,"Reminder setup failed: "+e.getMessage(),Toast.LENGTH_LONG).show()); }
        }
    }
}