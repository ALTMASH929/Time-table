# MyDay V6

Native Android timetable/reminder app.

## Build without Android Studio

This repository includes a GitHub Actions workflow. On a phone:
**GitHub → repository → Actions → Build MyDay APK → Run workflow → download the artifact.**

See `README_GITHUB_PHONE.txt` for exact steps.
