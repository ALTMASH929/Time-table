MYDAY V6 — NATIVE ANDROID PROJECT

This is the native Android Studio project for the MyDay app.

It keeps the V5 web UI inside a native Android shell and adds native Android notifications:
- POST_NOTIFICATIONS permission
- notification channel
- AlarmManager exact alarms
- reminders can fire while the app is not open
- tapping a notification opens MyDay
- uploaded timetable can schedule native reminders
- the V5 timetable/gym/diet/checklist UI remains included

BUILD:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated app-debug.apk.

IMPORTANT:
- Android Studio/Gradle must download the Android Gradle Plugin and AndroidX dependency.
- Exact alarms may require Android Settings permission on some devices.
- The current bridge schedules the imported timetable's start times. The in-app 5/10/15 minute settings remain in the UI; a production V7 should send those offsets to native AlarmManager too.
- This source is provided because this environment does not have an Android SDK/Gradle build toolchain, so I cannot truthfully attach a compiled APK from here.
