MYDAY V6 — BUILD APK FROM YOUR PHONE

You do NOT need Android Studio.

1. On your phone, open github.com and sign in.
2. Create a new repository, for example: MyDay-App
3. Upload ALL files/folders from this project ZIP.
   IMPORTANT: upload the .github folder too.
4. Make sure the main branch is named "main".
5. Open the repository -> Actions.
6. Tap "Build MyDay APK".
7. Tap "Run workflow" if it is not already running.
8. Wait for the green check.
9. Open the completed workflow run.
10. Scroll to Artifacts.
11. Download "MyDay-debug-APK".
12. Extract the downloaded ZIP. Inside is app-debug.apk.
13. Tap the APK to install it.

If Android asks for permission to install from this source, allow your browser/files app to install the APK.

The GitHub workflow builds the debug APK automatically. You don't need Android Studio.

If the workflow fails:
- Open Actions -> failed "Build MyDay APK".
- Copy the error and send it to ChatGPT; the project can then be fixed.
